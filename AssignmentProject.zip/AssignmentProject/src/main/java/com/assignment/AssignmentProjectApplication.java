package com.assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentProjectApplication.class, args);
	}

}
